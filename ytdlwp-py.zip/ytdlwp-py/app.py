from flask import Flask, request, render_template
import subprocess

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')
@app.route('/runcmd', methods=['POST'])
def run_command():
    link = request.form['command']
    print(link)
    # command =  "C:\\Program Files(x86)\\ytdl\\youtube-dl.exe -url " + link
    command = "ping" + link

    try:
        result = subprocess.run(command, shell=True, capture_output=True, text=True)
        output = result.stdout
        return f"Success: <pre>{output}</pre>"
    except Exception as e:
        return f"Failed to execute command: {e}"

if __name__ == '__main__':
    app.run(debug=True)
